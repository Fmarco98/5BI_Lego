from flask import Flask, render_template, request, redirect, url_for, jsonify
import paho.mqtt.client as mqtt
import pymongo
from datetime import datetime
import threading
import time

app = Flask(__name__)

# --- Configurazione MQTT ---
MQTT_BROKER = "localhost"  # Indirizzo IP del tuo broker MQTT (es. Raspberry Pi IP)
MQTT_PORT = 1883
MQTT_TOPIC_BASE = "lego_bwe/"
MQTT_TOPIC_STATUS = MQTT_TOPIC_BASE + "status" # Topic per lo stato del Raspberry Pi
MQTT_TOPIC_QUANTITY = MQTT_TOPIC_BASE + "dug_quantity" # Topic per la quantità scavata

# Inizializzazione del client MQTT
mqtt_client = mqtt.Client()
mqtt_connected = False # Variabile per tenere traccia dello stato della connessione MQTT

# --- Configurazione MongoDB ---
MONGO_URI = "mongodb://localhost:27017/" # Assicurati che MongoDB sia in esecuzione su questa porta
MONGO_DB_NAME = "lego_bwe_data"
MONGO_COLLECTION_NAME = "dug_quantities"

try:
    mongo_client = pymongo.MongoClient(MONGO_URI)
    db = mongo_client[MONGO_DB_NAME]
    collection = db[MONGO_COLLECTION_NAME]
    print("Connesso a MongoDB!")
except pymongo.errors.ConnectionFailure as e:
    print(f"Errore di connessione a MongoDB: {e}")
    # Considera una gestione degli errori più robusta qui (es. disabilitare funzionalità DB)

# --- Variabili di stato per la dashboard ---
current_dug_quantity = 0 # Placeholder per la quantità scavata ricevuta dal robot
raspberry_pi_status = "Disconnesso" # Stato iniziale della connessione al Raspberry Pi

# --- Funzioni di callback MQTT ---
def on_connect(client, userdata, flags, rc):
    global mqtt_connected, raspberry_pi_status
    if rc == 0:
        print("Connesso al broker MQTT!")
        mqtt_connected = True
        raspberry_pi_status = "Connesso"
        # Sottoscrizione ai topic rilevanti
        client.subscribe(MQTT_TOPIC_STATUS)
        client.subscribe(MQTT_TOPIC_QUANTITY)
    else:
        print(f"Connessione al broker MQTT fallita con codice {rc}")
        mqtt_connected = False
        raspberry_pi_status = "Disconnesso"

def on_disconnect(client, userdata, rc):
    global mqtt_connected, raspberry_pi_status
    print(f"Disconnesso dal broker MQTT con codice: {rc}")
    mqtt_connected = False
    raspberry_pi_status = "Disconnesso"

def on_message(client, userdata, msg):
    global current_dug_quantity, raspberry_pi_status
    topic = msg.topic
    payload = msg.payload.decode()
    print(f"Ricevuto messaggio: Topic '{topic}', Payload '{payload}'")

    if topic == MQTT_TOPIC_STATUS:
        raspberry_pi_status = payload # Aggiorna lo stato del Raspberry Pi
    elif topic == MQTT_TOPIC_QUANTITY:
        try:
            current_dug_quantity = float(payload) # Assumiamo che la quantità sia un numero
        except ValueError:
            print(f"Avviso: Ricevuto quantità non numerica: {payload}")

# --- Funzione per il loop di connessione MQTT (retry automatico) ---
def mqtt_connection_loop():
    while True:
        if not mqtt_connected:
            print("Tentativo di riconnessione MQTT...")
            try:
                mqtt_client.reconnect()
            except Exception as e:
                print(f"Errore durante la riconnessione MQTT: {e}")
            time.sleep(5) # Attendi prima del prossimo tentativo
        time.sleep(1) # Controlla lo stato ogni secondo

# --- Avvia il thread per la riconnessione MQTT ---
mqtt_thread = threading.Thread(target=mqtt_connection_loop)
mqtt_thread.daemon = True # Il thread si chiuderà quando l'applicazione principale si chiude
mqtt_thread.start()

# --- Setup MQTT client ---
mqtt_client.on_connect = on_connect
mqtt_client.on_disconnect = on_disconnect
mqtt_client.on_message = on_message
mqtt_client.connect_async(MQTT_BROKER, MQTT_PORT, 60) # Connessione asincrona
mqtt_client.loop_start() # Avvia il loop in background per gestire la connessione

# --- Funzioni di controllo del Robot (inalterate, solo per completezza) ---

# Movimento Base
@app.route('/move_forward', methods=['POST'])
def move_forward():
    mqtt_client.publish(MQTT_TOPIC_BASE + "movement", "forward")
    print("Comando: Avanti")
    return redirect(url_for('index'))

@app.route('/move_backward', methods=['POST'])
def move_backward():
    mqtt_client.publish(MQTT_TOPIC_BASE + "movement", "backward")
    print("Comando: Indietro")
    return redirect(url_for('index'))

@app.route('/turn_left', methods=['POST'])
def turn_left():
    mqtt_client.publish(MQTT_TOPIC_BASE + "movement", "left")
    print("Comando: Sinistra")
    return redirect(url_for('index'))

@app.route('/turn_right', methods=['POST'])
def turn_right():
    mqtt_client.publish(MQTT_TOPIC_BASE + "movement", "right")
    print("Comando: Destra")
    return redirect(url_for('index'))

@app.route('/stop_movement', methods=['POST'])
def stop_movement():
    mqtt_client.publish(MQTT_TOPIC_BASE + "movement", "stop")
    print("Comando: Stop Movimento")
    return redirect(url_for('index'))

# Pistoni
@app.route('/pistons_up', methods=['POST'])
def pistons_up():
    mqtt_client.publish(MQTT_TOPIC_BASE + "pistons", "up")
    print("Comando: Pistoni Su")
    return redirect(url_for('index'))

@app.route('/pistons_down', methods=['POST'])
def pistons_down():
    mqtt_client.publish(MQTT_TOPIC_BASE + "pistons", "down")
    print("Comando: Pistoni Giù")
    return redirect(url_for('index'))

@app.route('/stop_pistons', methods=['POST'])
def stop_pistons():
    mqtt_client.publish(MQTT_TOPIC_BASE + "pistons", "stop")
    print("Comando: Stop Pistoni")
    return redirect(url_for('index'))

# Rotazione Torre
@app.route('/rotate_tower_right', methods=['POST'])
def rotate_tower_right():
    mqtt_client.publish(MQTT_TOPIC_BASE + "tower_rotation", "right")
    print("Comando: Rotazione Torre Destra")
    return redirect(url_for('index'))

@app.route('/rotate_tower_left', methods=['POST'])
def rotate_tower_left():
    mqtt_client.publish(MQTT_TOPIC_BASE + "tower_rotation", "left")
    print("Comando: Rotazione Torre Sinistra")
    return redirect(url_for('index'))

@app.route('/stop_tower_rotation', methods=['POST'])
def stop_tower_rotation():
    mqtt_client.publish(MQTT_TOPIC_BASE + "tower_rotation", "stop")
    print("Comando: Stop Rotazione Torre")
    return redirect(url_for('index'))

# Ruota che scava
@app.route('/digger_wheel_on', methods=['POST'])
def digger_wheel_on():
    mqtt_client.publish(MQTT_TOPIC_BASE + "digger_wheel", "on")
    print("Comando: Ruota Scavatrice On")
    return redirect(url_for('index'))

@app.route('/digger_wheel_off', methods=['POST'])
def digger_wheel_off():
    mqtt_client.publish(MQTT_TOPIC_BASE + "digger_wheel", "off")
    print("Comando: Ruota Scavatrice Off")
    return redirect(url_for('index'))

# Scarico
@app.route('/discharge_rotate_right', methods=['POST'])
def discharge_rotate_right():
    mqtt_client.publish(MQTT_TOPIC_BASE + "discharge_rotation", "right")
    print("Comando: Scarico Rotazione Destra")
    return redirect(url_for('index'))

@app.route('/discharge_rotate_left', methods=['POST'])
def discharge_rotate_left():
    mqtt_client.publish(MQTT_TOPIC_BASE + "discharge_rotation", "left")
    print("Comando: Scarico Rotazione Sinistra")
    return redirect(url_for('index'))

@app.route('/stop_discharge_rotation', methods=['POST'])
def stop_discharge_rotation():
    mqtt_client.publish(MQTT_TOPIC_BASE + "discharge_rotation", "stop")
    print("Comando: Stop Rotazione Scarico")
    return redirect(url_for('index'))

# Accensione/Spegnimento Lego
@app.route('/lego_power_on', methods=['POST'])
def lego_power_on():
    mqtt_client.publish(MQTT_TOPIC_BASE + "power", "on")
    print("Comando: Accensione Lego")
    return redirect(url_for('index'))

@app.route('/lego_power_off', methods=['POST'])
def lego_power_off():
    mqtt_client.publish(MQTT_TOPIC_BASE + "power", "off")
    print("Comando: Spegnimento Lego")
    return redirect(url_for('index'))

# --- Funzioni per la quantità scavata e MongoDB ---
@app.route('/save_dug_quantity', methods=['POST'])
def save_dug_quantity():
    if not mqtt_connected:
        print("Errore: Connessione MQTT non attiva, non posso salvare la quantità.")
        # Potresti aggiungere un messaggio flash o un errore visibile all'utente
        return redirect(url_for('index'))

    try:
        # Assicurati che current_dug_quantity sia un numero prima di salvarlo
        quantity_to_save = float(current_dug_quantity)
        record = {
            "quantity": quantity_to_save,
            "timestamp": datetime.now()
        }
        collection.insert_one(record)
        print(f"Quantità '{quantity_to_save}' salvata con timestamp: {record['timestamp']}")
    except ValueError:
        print(f"Errore: La quantità scavata non è un numero valido per il salvataggio: {current_dug_quantity}")
    except Exception as e:
        print(f"Errore durante il salvataggio su MongoDB: {e}")
    return redirect(url_for('index'))

@app.route('/get_dug_history', methods=['GET'])
def get_dug_history():
    try:
        # Recupera tutte le misurazioni, ordina per timestamp decrescente
        history = list(collection.find().sort("timestamp", pymongo.DESCENDING))
        # Formatta i dati per la visualizzazione sulla dashboard
        formatted_history = []
        for entry in history:
            formatted_history.append({
                "quantity": entry.get("quantity", "N/A"),
                "timestamp": entry.get("timestamp", datetime.now()).strftime("%Y-%m-%d %H:%M:%S")
            })
        return jsonify(formatted_history)
    except Exception as e:
        print(f"Errore durante il recupero dello storico da MongoDB: {e}")
        return jsonify({"error": "Impossibile recuperare lo storico"}), 500

# --- Rotte per lo stato della dashboard ---
@app.route('/get_dashboard_status', methods=['GET'])
def get_dashboard_status():
    return jsonify({
        "mqtt_connected": mqtt_connected,
        "raspberry_pi_status": raspberry_pi_status,
        "current_dug_quantity": current_dug_quantity
    })

# --- Pagina principale della Dashboard ---
@app.route('/')
def index():
    return render_template('dashboard.html',
                           mqtt_connected=mqtt_connected,
                           raspberry_pi_status=raspberry_pi_status,
                           current_dug_quantity=current_dug_quantity)

if __name__ == '__main__':
    # Esegui l'app Flask su tutte le interfacce disponibili sulla porta 5000
    # debug=True permette il ricaricamento automatico del server a ogni modifica
    app.run(host='0.0.0.0', port=5000, debug=True)